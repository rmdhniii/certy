# Certificate-Maker
 A web-based certification generator which provides tools to generate certifications for students with a simple user experience.

# Getting Started
**Just by three steps**
1. Open the page [Here](https://asraraljuhani.github.io/Certificate-Maker/).
2. Upload your certificate template.
3. Add the Names.

Voila! Your Certificates are READY :confetti_ball:

# Built With
* HTML
* CSS
* JavaScript
* [JsZip](https://stuk.github.io/jszip/)

# Author 
[Asrar Aljuhani](https://twitter.com/asraraljuhani)
